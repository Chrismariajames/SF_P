E-Commerce Snowflake Project Dataset

Files included:
1. customers.csv
2. products.csv
3. orders.csv
4. shipments.csv
5. inventory.csv
6. channels.csv
7. promotions.csv
8. shipping_methods.csv
9. customer_reviews.json
10. web_events_nested.json

Use cases:
- Local internal stage upload
- AWS S3 upload
- Azure ADLS upload
- Snowpipe auto-ingestion
- Bronze, Silver, Gold pipeline
- Streams and Tasks
- AI sentiment analysis on customer reviews
- Power BI dashboarding
- RBAC and masking demos
